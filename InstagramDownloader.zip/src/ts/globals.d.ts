/****************************************************************************************
 * Copyright (c) 2020. HuiiBuh                                                          *
 * This file (globals.d.ts) is part of InstagramDownloader which is released under      *
 * GNU LESSER GENERAL PUBLIC LICENSE.                                                   *
 * You are not allowed to use this code or this file for another project without        *
 * linking to the original source AND open sourcing your code.                          *
 ****************************************************************************************/

export {};

declare global {
    const PRODUCTION: boolean;
}
