import './options.scss';

(document.querySelector('#year') as HTMLElement).innerText = new Date().getFullYear().toString();
